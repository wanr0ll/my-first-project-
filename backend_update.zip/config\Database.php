<?php

/**
 * Database Configuration Class
 * Reads credentials from environment variables (Railway) or falls back to local XAMPP defaults.
 */

class Database
{
    private $host;
    private $user;
    private $pass;
    private $db_name;
    private $port;
    private $charset = 'utf8mb4';

    public $conn;

    public function __construct()
    {
        // Railway provides MYSQLHOST, MYSQLUSER, MYSQLPASSWORD, MYSQLDATABASE
        // Fall back to local XAMPP credentials for development
        // Railway MySQL plugin env vars (no underscore in MYSQLDATABASE)
        $this->host    = getenv('MYSQLHOST')      ?: 'localhost';
        $this->user    = getenv('MYSQLUSER')      ?: 'root';
        $this->pass    = getenv('MYSQLPASSWORD')  ?: '';
        $this->db_name = getenv('MYSQLDATABASE')  ?: getenv('MYSQL_DATABASE') ?: 'gha_asset_manager';
        $this->port    = getenv('MYSQLPORT')      ? (int)getenv('MYSQLPORT') : 3306;
    }

    public function connect()
    {
        $this->conn = new mysqli(
            $this->host,
            $this->user,
            $this->pass,
            $this->db_name,
            $this->port
        );

        if ($this->conn->connect_error) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Database connection failed: ' . $this->conn->connect_error
            ]);
            exit;
        }

        $this->conn->set_charset($this->charset);
        return $this->conn;
    }

    public function getConnection()
    {
        return $this->conn;
    }

    public function close()
    {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}
